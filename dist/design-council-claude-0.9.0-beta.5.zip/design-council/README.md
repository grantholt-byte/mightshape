# ◇ Design Council — Claude Code

Think wider. Frame better. Build what matters.

This is the generated Claude Code distribution of Design Council 0.9.0-beta.5. Invoke
it with `/design-think` or a matching natural-language request. Canonical source,
tests, research notes, privacy documentation, and the optional interview Site
live in the source repository from which this package was built.

Design Council is independent and is not affiliated with or endorsed by
Stanford University or the Stanford d.school.
